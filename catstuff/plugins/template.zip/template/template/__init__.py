from .config import plugin_file, config, mod_name, __version__, build
from .main import Template
