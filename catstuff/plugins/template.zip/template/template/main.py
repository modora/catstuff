from catstuff import core
from .config import mod_name, build


class Template(core.plugins.CSTask):
    def __init__(self):
        super().__init__(mod_name, build)  # everything above here is required

    def main(self):  # modify anything below here
        print('This is a sample task')
        return 'sample'
